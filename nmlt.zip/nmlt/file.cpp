// file.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "fstream"
#include "iostream"
#include "string"
using namespace std;

//Ghi du lieu vao filename, neu filename da ton tai thi xoa file cu va tao 1 filename moi
//Du lieu ghi vao filename la:
/*10	123.23
HelloCplusplus.*/

void Writefile(string filename)
{
    ofstream out(filename); /// Mo tap tin de ghi
	if(!out)	{/// Kiem tra co mo duoc tap tin hay khong
		cout << "Khong mo duoc file." << endl;
		return;
	}
	out << 10 << "\t" << 123.23 << endl; /// Ghi du lieu vao tap tin
	out << "HelloCplusplus.";
	out.close();  /// Dong tap tin
}

//Neu filename da ton tai thi ghi du lieu vao cuoi filename, neu filename chua ton tai thi tao file moi va ghi du lieu vao file
//Du lieu ghi vao filename la:
/*Append*/

void Appendfile(string filename)
{
    ofstream out(filename, ios::app);//Mo file filename de ghi tiep vao cuoi (tham so ios::app)
	if(!out)	{
		cout << "Khong mo duoc file.\n";
		return;
	}
	out << "Append" << endl; //ghi chuoi Append tiep vao cuoi file test
	out.close();
}

void Readfile(string filename)
{	
    int i;	
    float f;	
    char ch;
    char str[80];
	ifstream in(filename); // mo file de doc
	if(!in){
		cout << "Khong mo duoc file.\n";
		return;
	}
	/// Xac dinh cac gia tri tap tin, moi gia tri so cach nhau 1 tab hoac 1 khoang trang
	in >> i; // doc 1 so nguyen va luu vao bien i 
    in >> f; // doc 1 so thuc va luu vao bien f
    in >> ch; // doc 1 ky tu va luu vao bien ch
    in >> str; // doc chuoi ky tu (sau ky tu ch) va luu vao bien str
	/// Xuat cac bien ra man hinh
  	cout << i << " " << f << " " << ch << endl;
  	cout << str << endl;
  	in.close();
}

//Doc tung ky tu trong filename cho den khi ket thuc (eof)
void Readfile_untilEOF(string filename)
{
    char ch;
	ifstream in(filename); //mo file de doc
	if(!in)
    {
		cout << "Khong mo duoc file.\n";
		return;
	}
	while(!in.eof())
    { /// Kiem tra cuoi tap tin hay chua
		in.get(ch); // doc 1 ky tu trong filename va luu vao bien ch
		if(!in.eof()) /// tranh xuat ky tu eof
		    cout << ch;
	}
	in.close();

}

//Doc tung dong trong file
void Readfile_Line(string filename)
{
    ifstream in(filename);
	if(!in)	{			
		cout << "Khong mo duoc file.\n";
		return;
	}	
	
    string str;
	while(getline(in, str)) /// vong lap xac dinh tung dong trong tap tin
		cout << str << endl;
	in.close();
}

int main(){
    string filename = "C:\\NMLT\\test.txt"; // duong dan den file "test.txt"
	//Writefile(filename);
    //Appendfile(filename);
    //Readfile(filename);
    //Readfile_untilEOF(filename);
    Readfile_Line(filename);
	return 0;
}


